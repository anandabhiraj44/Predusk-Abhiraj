-- Insert profile
INSERT INTO profile (name, email, education, github, linkedin, portfolio)
VALUES (
  'Abhiraj Anand',
  'anandabhiraj44@gmail.com',
  'B.Tech in Information Technology, Semester VII',
  'https://github.com/anandabhiraj44',
  'https://www.linkedin.com/in/abhiraj-anand-ab24a7303/',
  'https://abhiranandj-portfolio.com'
);

-- Insert skills
INSERT INTO skills (profile_id, skill_name, level) VALUES
(1, 'JavaScript', 8),
(1, 'React', 7),
(1, 'Node.js', 8),
(1, 'Express', 7),
(1, 'SQL', 6),
(1, 'MongoDB', 6),
(1, 'Python', 7);

-- Insert projects
INSERT INTO projects (profile_id, title, description, link) VALUES
(1, 'Portfolio Website', 'A personal portfolio built with React and Tailwind.', 'https://abhiraj-portfolio.com'),
(1, 'Chatbot App', 'AI-powered chatbot built with Node.js and Express.', 'https://github.com/abhirajanand/chatbot-app'),
(1, 'Student Management System', 'CRUD app using React + Express + SQLite.', 'https://github.com/abhirajanand/student-management');
