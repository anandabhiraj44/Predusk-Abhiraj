// db.js
import sqlite3 from "sqlite3";
sqlite3.verbose();

// This creates (or opens) a local SQLite database file
const db = new sqlite3.Database("./meapi.db");

db.serialize(() => {
  // Turn on foreign key constraints
  db.run("PRAGMA foreign_keys=ON");
});

export default db;
