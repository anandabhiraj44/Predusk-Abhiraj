-- Create Profile table
CREATE TABLE IF NOT EXISTS profile (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT,
  education TEXT,
  github TEXT,
  linkedin TEXT,
  portfolio TEXT
);

-- Create Skills table
CREATE TABLE IF NOT EXISTS skills (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profile_id INTEGER,
  skill_name TEXT,
  level INTEGER,
  FOREIGN KEY (profile_id) REFERENCES profile(id) ON DELETE CASCADE
);

-- Create Projects table
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  profile_id INTEGER,
  title TEXT,
  description TEXT,
  link TEXT,
  FOREIGN KEY (profile_id) REFERENCES profile(id) ON DELETE CASCADE
);
