// server.js
import express from "express";
import cors from "cors";
import db from "./db.js";


const app = express();
app.use(cors());
app.use(express.json());

// ✅ Log every request in terminal
app.use((req, res, next) => {
  console.log(`➡️  ${req.method} ${req.url}`);
  next();
});

// ✅ Root route
// ✅ Root route
app.get("/", (req, res) => {
  res.send("🚀 Me-API Playground Backend is running! Try /health, /profile, /skills/top, /projects");
});


// ✅ Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

// ✅ Profile
app.get("/profile", (req, res) => {
  db.get("SELECT * FROM profile LIMIT 1", (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(row || {});
  });
});

app.post("/profile", (req, res) => {
  const { name, email, education, github, linkedin, portfolio } = req.body;
  db.run(
    "INSERT INTO profile (name, email, education, github, linkedin, portfolio) VALUES (?, ?, ?, ?, ?, ?)",
    [name, email, education, github, linkedin, portfolio],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

// ✅ Skills
app.get("/skills/top", (req, res) => {
  db.all("SELECT * FROM skills ORDER BY level DESC LIMIT 5", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// ✅ Projects (with optional filter by skill)
app.get("/projects", (req, res) => {
  const { skill } = req.query;
  if (skill) {
    db.all(
      `SELECT p.* FROM projects p
       JOIN skills s ON p.profile_id = s.profile_id
       WHERE s.skill_name LIKE ?`,
      [`%${skill}%`],
      (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
      }
    );
  } else {
    db.all("SELECT * FROM projects", (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    });
  }
});

// ✅ Start server
const PORT = 4000;
app.listen(PORT, () =>
  console.log(`✅ Backend running on http://localhost:${PORT}`)
);
